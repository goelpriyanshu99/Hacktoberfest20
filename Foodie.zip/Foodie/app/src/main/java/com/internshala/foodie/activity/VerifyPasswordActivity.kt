package com.internshala.foodie.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.internshala.foodie.R

class VerifyPasswordActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_verify_password)
    }
}