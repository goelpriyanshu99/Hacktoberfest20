package com.internshala.foodie.model

data class Restaurant (
    val restaurantId: String,
    val restaurantName: String,
    val restaurantRating: String,
    val restaurantRate: String,
    val restaurantImage: String
)