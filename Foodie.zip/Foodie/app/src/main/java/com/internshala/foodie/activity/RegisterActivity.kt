package com.internshala.foodie.activity

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.Settings
import android.util.Patterns
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.internshala.foodie.R
import com.internshala.foodie.util.ConnectionManager
import kotlinx.android.synthetic.main.activity_register.*
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

class RegisterActivity : AppCompatActivity() {

    lateinit var txtName: EditText
    lateinit var txtEmail: EditText
    lateinit var txtMobile: EditText
    lateinit var txtDeliveryAddress: EditText
    lateinit var txtPassword: EditText
    lateinit var txtCpassword: EditText
    lateinit var btnRegister: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        txtName = findViewById(R.id.txtName)
        txtEmail = findViewById(R.id.txtEmail)
        txtMobile = findViewById(R.id.txtMobile)
        txtDeliveryAddress = findViewById(R.id.txtDeliveryAddress)
        txtPassword = findViewById(R.id.txtPassword)
        txtCpassword = findViewById(R.id.txtCpassword)
        btnRegister = findViewById(R.id.btnRegister)

        btnRegister.setOnClickListener {


            var name = txtName.text.toString()
            var mobile = txtMobile.text.toString()
            var email = txtEmail.text.toString()
            var password = txtPassword.text.toString()
            var address = txtDeliveryAddress.text.toString()

            if (validate()) {
                    val queue = Volley.newRequestQueue(this@RegisterActivity)
                    val url = "http://13.235.250.119/v2/register/fetch_result"

                    val jsonParams = JSONObject()
                    jsonParams.put("name", name)
                    jsonParams.put("mobile_number", mobile)
                    jsonParams.put("password", password)
                    jsonParams.put("address", address)
                    jsonParams.put("email", email)

                    if (ConnectionManager().checkConnectivity(this@RegisterActivity)) {
                        val jsonObjectRequest = object :
                            JsonObjectRequest(
                                Request.Method.POST,
                                url,
                                jsonParams,
                                Response.Listener {
                                    //Here we handle responses
                                    try {
                                        val data1 = it.getJSONObject("data")
                                        val success = data1.getBoolean("success")
                                        if (success) {
                                            val data2 = data1.getJSONObject("data")
                                            val id = data2.getString("user_id")
                                            Toast.makeText(
                                                this@RegisterActivity,
                                                id,
                                                Toast.LENGTH_LONG
                                            )
                                                .show()
                                            startActivity(
                                                Intent(
                                                    this@RegisterActivity,
                                                    HomeActivity::class.java
                                                )
                                            )
                                        } else {
                                            val error = data1.getString("errorMessage")
                                            Toast.makeText(
                                                this@RegisterActivity, error,
                                                Toast.LENGTH_LONG
                                            ).show()
                                        }
                                    } catch (e: JSONException) {
                                        Toast.makeText(
                                            this@RegisterActivity,
                                            "Some unexpected error occurred!!!",
                                            Toast.LENGTH_LONG
                                        ).show()
                                    }

                                },
                                Response.ErrorListener {
                                    //Here we handle errors
                                    Toast.makeText(
                                        this@RegisterActivity,
                                        "Volley error $it!!!",
                                        Toast.LENGTH_LONG
                                    )
                                        .show()
                                }) {
                            override fun getHeaders(): MutableMap<String, String> {
                                val headers = HashMap<String, String>()
                                headers["content-type"] = "application/json"
                                headers["token"] = "ca9b8a7a1593d4"
                                return headers
                            }
                        }

                        queue.add(jsonObjectRequest)
                    } else {
                        //Internet is not available
                        val dialog = AlertDialog.Builder(this@RegisterActivity)
                        dialog.setTitle("Error")
                        dialog.setMessage("Internet Connection is not Found")
                        dialog.setPositiveButton("Open Setting") { text, listener ->
                            val settingsIntent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
                            startActivity(settingsIntent)
                            finish()
                        }
                        dialog.setNegativeButton("Exit") { text, listener ->
                            ActivityCompat.finishAffinity(this@RegisterActivity)
                        }
                        dialog.show()
                        dialog.create()
                    }
                }
            }
        setUpToolbar()
    }
    fun setUpToolbar(){
        setSupportActionBar(toolbar)
        supportActionBar?.title = "Register Yourself"
        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }
        fun validate() :Boolean{
            var validEmail = Patterns.EMAIL_ADDRESS.matcher(txtEmail.text.toString()).matches()
            if (txtName.text.toString().length < 3) {
                if (txtName.text.toString().isEmpty()) {
                    txtName.error = "Name should not be blank"
                    return false
                }else{
                    txtName.error = "Minimum 3 characters of username required"
                    return false
                }
            }
        else if(!validEmail){
                if(txtEmail.text.toString().isEmpty()) {
                    txtEmail.error = "Email required"
                    return false
                }else{
                    txtEmail.error = "invalid email"
                    return false
                }
        }else if(txtMobile.text.toString().length < 10){
                if(txtMobile.text.toString().isEmpty()) {
                    txtMobile.error = "Mobile number required"
                    return false
                }else{
                    txtMobile.error = "Invalid number"
                    return false
                }
        }else if(txtDeliveryAddress.text.toString().isEmpty()){
            txtDeliveryAddress.error = "Please enter your address"
                return false
        }else if(txtPassword.text.toString().length < 4){
                if(txtPassword.text.toString().isEmpty()) {
                    txtPassword.error = "Mandatory"
                    return false
                }else{
                    txtPassword.error = "Minimum 6 characters in password required"
                    return false
                }
        }else if(txtCpassword.text.toString() != txtPassword.text.toString()){
            txtCpassword.error = "Password & Confirm password do not match"
                return false
        }
        return true
    }
}
