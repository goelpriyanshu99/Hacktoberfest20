package com.internshala.foodie.database

class RegistrationDatabase {
}