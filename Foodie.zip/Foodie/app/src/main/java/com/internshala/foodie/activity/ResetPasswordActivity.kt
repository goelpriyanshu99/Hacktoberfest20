package com.internshala.foodie.activity

import android.app.AlertDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.internshala.foodie.R
import com.internshala.foodie.util.ConnectionManager
import kotlinx.android.synthetic.main.activity_login.*
import org.json.JSONObject

class ResetPasswordActivity : AppCompatActivity() {

    lateinit var txtHead: TextView
    lateinit var etOtp: EditText
    lateinit var etPassword: EditText
    lateinit var etCpassword: EditText
    lateinit var btnSubmit: Button
    lateinit var number: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reset_password)

        txtHead = findViewById(R.id.txtHead)
        etOtp = findViewById(R.id.etOtp)
        etPassword = findViewById(R.id.etPassword)
        etCpassword = findViewById(R.id.etCpassword)
        btnSubmit = findViewById(R.id.btnSubmit)

        btnSubmit.setOnClickListener {
            number = getIntent().getStringExtra("Keynumber")
            val password = etPassword.text.toString()
            val otp = etOtp.text.toString()

            if(password != etCpassword.text.toString()){
                Toast.makeText(this@ResetPasswordActivity, "Passsword do not match", Toast.LENGTH_SHORT).show()
            }else{
                val queue = Volley.newRequestQueue(this@ResetPasswordActivity)
                val url = "http://13.235.250.119/v2/reset_password/fetch_result"

                val jsonParams = JSONObject()
                jsonParams.put("mobile_number", number)
                jsonParams.put("password", password)
                jsonParams.put("otp", otp)
                if(ConnectionManager().checkConnectivity(this@ResetPasswordActivity)){
                    val jsonObjectRequest = object : JsonObjectRequest(Request.Method.POST, url, jsonParams, Response.Listener {
                        //Here we handle responses
                        try{
                            val data = it.getJSONObject("data")
                            val success = data.getBoolean("success")
                            if(success){
                                val successMessage = data.getString("successMessage")
                                Toast.makeText(this@ResetPasswordActivity, successMessage, Toast.LENGTH_SHORT).show()
                                startActivity(Intent(this@ResetPasswordActivity, LoginActivity::class.java))
                            }else {
                                val error = data.getString("errorMessage")
                                Toast.makeText(
                                    this@ResetPasswordActivity, error,
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }catch (e: Exception){
                            Toast.makeText(this@ResetPasswordActivity, "Some error occurred!!!", Toast.LENGTH_LONG).show()
                        }
                    }, Response.ErrorListener {
                        //Here we handle errors
                        Toast.makeText(this@ResetPasswordActivity, "Volley error $it", Toast.LENGTH_LONG).show()
                    }){
                        override fun getHeaders(): MutableMap<String, String> {
                            val headers = HashMap<String, String>()
                            headers["content-type"] = "application/json"
                            headers["token"] = "ca9b8a7a1593d4"
                            return headers
                        }
                    }
                    queue.add(jsonObjectRequest)
                }else{
                    //Internet is not available
                    val dialog = AlertDialog.Builder(this@ResetPasswordActivity)
                    dialog.setTitle("Error")
                    dialog.setMessage("Internet Connection is not Found")
                    dialog.setPositiveButton("Open Setting") { text, listener ->
                        val settingsIntent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
                        startActivity(settingsIntent)
                        finish()
                    }
                    dialog.setNegativeButton("Exit") { text, listener ->
                        ActivityCompat.finishAffinity(this@ResetPasswordActivity)
                    }
                    dialog.show()
                    dialog.create()
                }
            }
        }
    }
}