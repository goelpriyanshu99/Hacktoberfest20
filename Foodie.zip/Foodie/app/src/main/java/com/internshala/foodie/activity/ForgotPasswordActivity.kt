package com.internshala.foodie.activity

import android.app.AlertDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.internshala.foodie.R
import com.internshala.foodie.util.ConnectionManager
import kotlinx.android.synthetic.main.activity_forgot_password.*
import org.json.JSONException
import org.json.JSONObject
import java.lang.Exception

class ForgotPasswordActivity : AppCompatActivity() {

    lateinit var txtMobile: EditText
    lateinit var txtEmail: EditText
    lateinit var btnNext: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_password)

        txtMobile = findViewById(R.id.txtMobile)
        txtEmail = findViewById(R.id.txtEmail)
        btnNext = findViewById(R.id.btnNext)

        btnNext.setOnClickListener {
            val number = txtMobile.text.toString()
            val email = txtEmail.text.toString()
            var validEmail = Patterns.EMAIL_ADDRESS.matcher(email).matches()

            if (number.length < 10) {
                Toast.makeText(this@ForgotPasswordActivity, "Invalid number", Toast.LENGTH_LONG)
                    .show()
            } else if (!validEmail) {
                Toast.makeText(this@ForgotPasswordActivity, "Not a valid email", Toast.LENGTH_LONG)
                    .show()
            } else {
                val queue = Volley.newRequestQueue(this@ForgotPasswordActivity)
                val url = "http://13.235.250.119/v2/forgot_password/fetch_result"

                val jsonParams = JSONObject()
                jsonParams.put("mobile_number", number)
                jsonParams.put("email", email)

                if (ConnectionManager().checkConnectivity(this@ForgotPasswordActivity)) {
                    val jsonObjectRequest = object :
                        JsonObjectRequest(Request.Method.POST, url, jsonParams, Response.Listener {
                            //Here we will handle response from API
                            try{
                                val data = it.getJSONObject("data")
                                val success = data.getBoolean("success")
                                if(success){
                                    val intent = Intent(this@ForgotPasswordActivity, ResetPasswordActivity::class.java)
                                    intent.putExtra("Keynumber", number)
                                    val dialog = AlertDialog.Builder(this@ForgotPasswordActivity)
                                    dialog.setTitle("Information")
                                    dialog.setMessage("Please refer to the previous mail for OTP.")
                                    dialog.setPositiveButton("OK"){text, listener ->
                                        startActivity(intent)
                                        finish()
                                    }
                                    dialog.create()
                                    dialog.show()
                                }else{
                                    val error = data.getString("errorMessage")
                                    Toast.makeText(this@ForgotPasswordActivity, error, Toast.LENGTH_SHORT).show()
                                }
                            }catch (e: JSONException){
                                Toast.makeText(this@ForgotPasswordActivity, "Some error occurred!!!", Toast.LENGTH_LONG).show()
                            }
                        }, Response.ErrorListener {
                            //Here we will handle errors
                            Toast.makeText(this@ForgotPasswordActivity, "Volley error $it", Toast.LENGTH_LONG).show()
                        }){
                        override fun getHeaders(): MutableMap<String, String> {
                            val headers = HashMap<String, String>()
                            headers["content-type"] = "application/json"
                            headers["token"] = "ca9b8a7a1593d4"
                            return headers
                        }
                    }
                    queue.add(jsonObjectRequest)
                }else{
                    //Internet is not available
                    val dialog = AlertDialog.Builder(this@ForgotPasswordActivity)
                    dialog.setTitle("Error")
                    dialog.setMessage("Internet Connection is not Found")
                    dialog.setPositiveButton("Open Setting") { text, listener ->
                        val settingsIntent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
                        startActivity(settingsIntent)
                        finish()
                    }
                    dialog.setNegativeButton("Exit") { text, listener ->
                        ActivityCompat.finishAffinity(this@ForgotPasswordActivity)
                    }
                    dialog.show()
                    dialog.create()
                }
            }
        }

    }
}