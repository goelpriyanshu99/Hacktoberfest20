package com.internshala.foodie.activity

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.internshala.foodie.R
import com.internshala.foodie.util.ConnectionManager
import org.json.JSONObject
import java.lang.Exception

class LoginActivity : AppCompatActivity() {

    lateinit var txtMobile: EditText
    lateinit var txtPassword: EditText
    lateinit var btnLogIn: Button
    lateinit var txtForgotPassword: TextView
    lateinit var txtCreate: TextView

    lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        sharedPreferences = getSharedPreferences(getString(R.string.login_preference), Context.MODE_PRIVATE)
        setContentView(R.layout.activity_login)

        val isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false)
        if(isLoggedIn){
            startActivity(Intent(this@LoginActivity, HomeActivity::class.java))
            finish()
        }

        txtMobile = findViewById(R.id.txtMobile)
        txtPassword = findViewById(R.id.txtPassword)
        btnLogIn = findViewById(R.id.btnLogIn)
        txtForgotPassword = findViewById(R.id.txtForgotPassword)
        txtCreate = findViewById(R.id.txtCreate)
        /*val mobileNumber: String = txtMobile.text.toString()
        val password: String = txtPassword.text.toString()*/

        txtCreate.setOnClickListener {
            val intent = Intent(this@LoginActivity, RegisterActivity::class.java)
            startActivity(intent)
        }

        txtForgotPassword.setOnClickListener {
            val intent = Intent(this@LoginActivity, ForgotPasswordActivity::class.java)
            startActivity(intent)
        }

        btnLogIn.setOnClickListener {
            val number = txtMobile.text.toString()
            val pass = txtPassword.text.toString()
            if(number.length < 10){
                Toast.makeText(this@LoginActivity, "Invalid Number", Toast.LENGTH_LONG).show()
            }else if (pass.length < 4){
                Toast.makeText(this@LoginActivity, "Check your password", Toast.LENGTH_LONG).show()
            }else {
                val queue = Volley.newRequestQueue(this@LoginActivity)
                val url = "http://13.235.250.119/v2/login/fetch_result"

                val jsonParams = JSONObject()
                jsonParams.put("mobile_number", number)
                jsonParams.put("password", pass)
                if (ConnectionManager().checkConnectivity(this@LoginActivity)) {
                    val jsonObjectRequest = object :
                        JsonObjectRequest(Request.Method.POST, url, jsonParams, Response.Listener {
                            //Here we handle responses from server API
                            try{
                                val data1 = it.getJSONObject("data")
                                val success = data1.getBoolean("success")
                                if(success){
                                    val data2 = data1.getJSONObject("data")
                                    val name1 = data2.getString("name")
                                    savedPreference()
                                    startActivity(Intent(this@LoginActivity, HomeActivity::class.java))
                                    Toast.makeText(this@LoginActivity, name1, Toast.LENGTH_SHORT).show()
                                }else {
                                    val error = data1.getString("errorMessage")
                                    Toast.makeText(
                                        this@LoginActivity, error,
                                        Toast.LENGTH_LONG
                                    ).show()
                                }
                            }catch (e: Exception){
                                Toast.makeText(this@LoginActivity, "Some error occurred!!!", Toast.LENGTH_LONG).show()
                            }
                        }, Response.ErrorListener {
                            //Here we handle errors
                            Toast.makeText(this@LoginActivity, "Volley error $it", Toast.LENGTH_LONG).show()
                        }) {
                        override fun getHeaders(): MutableMap<String, String> {
                            val headers = HashMap<String, String>()
                            headers["content-type"] = "application/json"
                            headers["token"] = "ca9b8a7a1593d4"
                            return headers
                        }
                    }

                    queue.add(jsonObjectRequest)
                }else{
                    //Internet is not available
                    val dialog = AlertDialog.Builder(this@LoginActivity)
                    dialog.setTitle("Error")
                    dialog.setMessage("Internet Connection is not Found")
                    dialog.setPositiveButton("Open Setting") { text, listener ->
                        val settingsIntent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
                        startActivity(settingsIntent)
                        finish()
                    }
                    dialog.setNegativeButton("Exit") { text, listener ->
                        ActivityCompat.finishAffinity(this@LoginActivity)
                    }
                    dialog.show()
                    dialog.create()
                }
            }
            val intent = Intent(this@LoginActivity, HomeActivity::class.java)
        }

        Toast.makeText(this@LoginActivity, "Welcome", Toast.LENGTH_SHORT).show()

    }
    fun savedPreference() {
        sharedPreferences.edit().putBoolean("isLoggedIn", true).apply()
    }
}